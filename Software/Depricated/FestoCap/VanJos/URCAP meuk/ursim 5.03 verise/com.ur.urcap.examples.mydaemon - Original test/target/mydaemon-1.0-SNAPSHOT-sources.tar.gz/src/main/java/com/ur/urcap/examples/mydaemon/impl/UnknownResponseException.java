package com.ur.urcap.examples.mydaemon.impl;

public class UnknownResponseException extends Exception {
}
