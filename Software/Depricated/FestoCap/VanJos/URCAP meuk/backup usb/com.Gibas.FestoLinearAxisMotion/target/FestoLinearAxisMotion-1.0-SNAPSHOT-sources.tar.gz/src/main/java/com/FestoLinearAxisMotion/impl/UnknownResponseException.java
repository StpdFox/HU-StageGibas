package com.FestoLinearAxisMotion.impl;

public class UnknownResponseException extends Exception {
}
